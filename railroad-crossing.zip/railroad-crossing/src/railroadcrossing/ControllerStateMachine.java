package railroadcrossing;

public class ControllerStateMachine {
    private enum State {
        IDLE, APPROACHING, CROSSING, LEAVING
    }

    private State currentState;

    public ControllerStateMachine() {
        currentState = State.IDLE;
    }

    public void handleEvent(String event) {
        switch (event) {
            case "TrainDetected":
                trainApproaching();
                break;
            case "TrainCleared":
                trainLeaving();
                break;
            default:
                System.out.println("Unhandled event: " + event);
        }
    }

    private void trainApproaching() {
        System.out.println("Train is approaching. Close gates.");
        currentState = State.APPROACHING;
    }

    private void trainLeaving() {
        System.out.println("Train has left the crossing.");
        currentState = State.LEAVING;
    }

    public String getCurrentState() {
        return currentState.name();
    }
}
