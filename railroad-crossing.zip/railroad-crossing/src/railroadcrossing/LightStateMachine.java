package railroadcrossing;

public class LightStateMachine {
    private enum State { GREEN, RED }
    
    private State currentState;

    public LightStateMachine() {
        currentState = State.GREEN;
    }

    public void handleEvent(String event) {
        switch (event) {
            case "TurnRed":
                turnRed();
                break;
            case "TurnGreen":
                turnGreen();
                break;
            default:
                System.out.println("Unhandled event: " + event);
        }
    }

    private void turnRed() {
        System.out.println("Light is turning red.");
        currentState = State.RED;
    }

    private void turnGreen() {
        System.out.println("Light is turning green.");
        currentState = State.GREEN;
    }

    public String getCurrentState() {
        return currentState.name();
    }
}
