package railroadcrossing;

public class Main {
    public static void main(String[] args) {
        // Initialize the state machines
        ControllerStateMachine controller = new ControllerStateMachine();
        GateStateMachine gate = new GateStateMachine();
        LightStateMachine light = new LightStateMachine();

        // Simulate the railroad crossing scenario
        System.out.println("Train is approaching the crossing.");
        controller.handleEvent("TrainDetected"); // Train detected, light turns red, gate closes
        light.handleEvent("TurnRed");
        gate.handleEvent("CloseGate");

        // Simulate the train passing through the crossing
        System.out.println("Train is crossing.");

        // Simulate the train leaving the crossing
        System.out.println("Train has left the crossing.");
        controller.handleEvent("TrainCleared"); // Train cleared, light turns green, gate opens
        light.handleEvent("TurnGreen");
        gate.handleEvent("OpenGate");

        // Final states
        System.out.println("Final States:");
        System.out.println("Controller State: " + controller.getCurrentState());
        System.out.println("Gate State: " + gate.getCurrentState());
        System.out.println("Light State: " + light.getCurrentState());
    }
}
