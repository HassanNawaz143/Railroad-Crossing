package railroadcrossing;

public class GateStateMachine {
    private enum State {
        OPEN, CLOSED
    }

    private State currentState;

    public GateStateMachine() {
        currentState = State.OPEN;
    }

    public void handleEvent(String event) {
        switch (event) {
            case "CloseGate":
                closeGate();
                break;
            case "OpenGate":
                openGate();
                break;
            default:
                System.out.println("Unhandled event: " + event);
        }
    }

    private void closeGate() {
        System.out.println("Gate is closing.");
        currentState = State.CLOSED;
    }

    private void openGate() {
        System.out.println("Gate is opening.");
        currentState = State.OPEN;
    }

    public String getCurrentState() {
        return currentState.name();
    }
}
